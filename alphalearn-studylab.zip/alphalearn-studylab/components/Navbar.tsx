"use client";

import { useEffect, useState } from "react";
import { MessageCircle, Instagram, Menu, X } from "lucide-react";
import { buildInstagramLink, buildWhatsAppLink } from "@/lib/site-config";

const navLinks = [
  { label: "Catalog", href: "#catalog" },
  { label: "How it works", href: "#how-it-works" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-paper/90 backdrop-blur-md shadow-soft"
          : "bg-paper/70 backdrop-blur-sm"
      }`}
    >
      <div className="mx-auto flex max-w-8xl items-center justify-between px-5 py-3.5 sm:px-8">
        <a href="#top" className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-navy text-paper font-display text-base font-semibold">
            A
          </span>
          <span className="font-display text-lg font-semibold tracking-tight text-navy">
            AlphaLearn <span className="italic font-normal">Studylab</span>
          </span>
        </a>

        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-[15px] font-medium text-navy/80 transition-colors hover:text-marker"
            >
              {link.label}
            </a>
          ))}
          <a
            href={buildWhatsAppLink("Hi! I'd like to know more about AlphaLearn Studylab worksheets.")}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-[15px] font-medium text-navy/80 transition-colors hover:text-green"
          >
            <MessageCircle size={17} strokeWidth={2} />
            WhatsApp
          </a>
          <a
            href={buildInstagramLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-[15px] font-medium text-navy/80 transition-colors hover:text-marker"
          >
            <Instagram size={17} strokeWidth={2} />
            Instagram
          </a>
        </nav>

        <button
          className="flex items-center justify-center rounded-full p-2 text-navy md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-navy/10 bg-paper px-5 pb-5 pt-2 md:hidden">
          <nav className="flex flex-col gap-1">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-2 py-2.5 text-[15px] font-medium text-navy/85 hover:bg-navy/5"
              >
                {link.label}
              </a>
            ))}
            <a
              href={buildWhatsAppLink("Hi! I'd like to know more about AlphaLearn Studylab worksheets.")}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 rounded-lg px-2 py-2.5 text-[15px] font-medium text-navy/85 hover:bg-navy/5"
            >
              <MessageCircle size={17} /> WhatsApp
            </a>
            <a
              href={buildInstagramLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 rounded-lg px-2 py-2.5 text-[15px] font-medium text-navy/85 hover:bg-navy/5"
            >
              <Instagram size={17} /> Instagram
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
