"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, SearchX } from "lucide-react";
import { worksheets, subjects, classes, type Subject, type SchoolClass } from "@/lib/worksheets";
import WorksheetCard from "./WorksheetCard";

type ClassFilter = "all" | SchoolClass;

export default function Catalog() {
  const [classFilter, setClassFilter] = useState<ClassFilter>("all");
  const [subjectFilters, setSubjectFilters] = useState<Subject[]>([]);
  const [query, setQuery] = useState("");

  const toggleSubject = (subject: Subject) => {
    setSubjectFilters((prev) =>
      prev.includes(subject) ? prev.filter((s) => s !== subject) : [...prev, subject]
    );
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return worksheets.filter((w) => {
      const matchesClass = classFilter === "all" || w.class === classFilter;
      const matchesSubject =
        subjectFilters.length === 0 || subjectFilters.includes(w.subject);
      const matchesQuery =
        q.length === 0 ||
        w.title.toLowerCase().includes(q) ||
        w.unit.toLowerCase().includes(q) ||
        w.subject.toLowerCase().includes(q);
      return matchesClass && matchesSubject && matchesQuery;
    });
  }, [classFilter, subjectFilters, query]);

  return (
    <section id="catalog" className="relative px-5 py-20 sm:px-8 lg:py-28">
      <div className="mx-auto max-w-8xl">
        <div className="mb-10 max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-wide text-marker">
            The catalog
          </p>
          <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-navy sm:text-4xl">
            Find the chapter you need.
          </h2>
          <p className="mt-3 text-navy/65">
            Filter by class and subject, or search for a chapter by name.
          </p>
        </div>

        {/* Class filter */}
        <div className="mb-4 flex flex-wrap gap-2.5">
          <button
            onClick={() => setClassFilter("all")}
            className={`chip ${
              classFilter === "all"
                ? "border-navy bg-navy text-paper"
                : "border-navy/15 bg-card text-navy/70 hover:border-navy/30"
            }`}
          >
            All classes
          </button>
          {classes.map((c) => (
            <button
              key={c}
              onClick={() => setClassFilter(c)}
              className={`chip ${
                classFilter === c
                  ? "border-navy bg-navy text-paper"
                  : "border-navy/15 bg-card text-navy/70 hover:border-navy/30"
              }`}
            >
              Class {c}
            </button>
          ))}
        </div>

        {/* Subject chips */}
        <div className="mb-7 flex flex-wrap gap-2.5">
          {subjects.map((s) => {
            const active = subjectFilters.includes(s);
            return (
              <button
                key={s}
                onClick={() => toggleSubject(s)}
                aria-pressed={active}
                className={`chip ${
                  active
                    ? "border-green bg-green-light text-green-dark"
                    : "border-navy/15 bg-card text-navy/70 hover:border-green/40"
                }`}
              >
                {s}
              </button>
            );
          })}
        </div>

        {/* Search bar */}
        <div className="mb-10 max-w-md">
          <div className="flex items-center gap-2.5 rounded-full border border-navy/15 bg-card px-4 py-2.5 shadow-soft focus-within:border-green/50">
            <Search size={18} className="shrink-0 text-navy/45" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search chapters..."
              className="w-full bg-transparent text-[15px] text-navy placeholder:text-navy/40 focus:outline-none"
            />
          </div>
        </div>

        {/* Results */}
        {filtered.length > 0 ? (
          <motion.div
            layout
            className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3"
          >
            <AnimatePresence mode="popLayout">
              {filtered.map((w) => (
                <WorksheetCard key={w.id} worksheet={w} />
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <div className="flex flex-col items-center justify-center rounded-card border border-dashed border-navy/20 bg-card/60 px-6 py-16 text-center">
            <SearchX size={30} className="mb-3 text-navy/30" />
            <p className="font-display text-lg font-semibold text-navy">
              No chapters match yet
            </p>
            <p className="mt-1 max-w-sm text-sm text-navy/55">
              Try a different class, clear a subject filter, or search a
              shorter chapter name.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
