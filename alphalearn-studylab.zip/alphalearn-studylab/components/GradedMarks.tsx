"use client";

import { motion } from "framer-motion";

const drawTransition = (delay = 0) => ({
  pathLength: { duration: 1, delay, ease: [0.65, 0, 0.35, 1] as const },
  opacity: { duration: 0.2, delay },
});

export function RedCheckmark({
  className = "",
  delay = 0,
}: {
  className?: string;
  delay?: number;
}) {
  return (
    <svg
      viewBox="0 0 60 60"
      className={className}
      fill="none"
      aria-hidden="true"
    >
      <motion.path
        d="M14 30.5 L25.5 42 L47 16"
        stroke="#B4392C"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={{ pathLength: 0, opacity: 0 }}
        whileInView={{ pathLength: 1, opacity: 1 }}
        viewport={{ once: true }}
        transition={drawTransition(delay)}
      />
    </svg>
  );
}

export function CircledScore({
  score = "18/20",
  className = "",
  delay = 0,
}: {
  score?: string;
  className?: string;
  delay?: number;
}) {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <svg viewBox="0 0 140 90" className="absolute inset-0 h-full w-full" aria-hidden="true">
        <motion.ellipse
          cx="70"
          cy="45"
          rx="62"
          ry="34"
          stroke="#B4392C"
          strokeWidth="3.5"
          fill="none"
          initial={{ pathLength: 0, opacity: 0 }}
          whileInView={{ pathLength: 1, opacity: 1 }}
          viewport={{ once: true }}
          transition={drawTransition(delay)}
        />
      </svg>
      <span className="relative font-hand text-2xl font-semibold text-marker-dark">
        {score}
      </span>
    </div>
  );
}

export function SquigglyUnderline({
  className = "",
  delay = 0,
}: {
  className?: string;
  delay?: number;
}) {
  return (
    <svg viewBox="0 0 200 12" className={className} fill="none" aria-hidden="true">
      <motion.path
        d="M2 8 Q 15 2, 28 8 T 54 8 T 80 8 T 106 8 T 132 8 T 158 8 T 184 8"
        stroke="#B4392C"
        strokeWidth="3"
        strokeLinecap="round"
        initial={{ pathLength: 0, opacity: 0 }}
        whileInView={{ pathLength: 1, opacity: 1 }}
        viewport={{ once: true }}
        transition={drawTransition(delay)}
      />
    </svg>
  );
}
