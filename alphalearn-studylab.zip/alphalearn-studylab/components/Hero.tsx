"use client";

import { motion } from "framer-motion";
import { ArrowRight, PlayCircle } from "lucide-react";
import { RedCheckmark, CircledScore, SquigglyUnderline } from "./GradedMarks";

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden px-5 pb-20 pt-14 sm:px-8 sm:pt-20 lg:pb-28">
      <div className="mx-auto grid max-w-8xl grid-cols-1 items-center gap-14 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10">
        {/* Left: copy */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-navy/15 bg-card px-4 py-1.5 text-sm font-medium text-navy/70 shadow-soft"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-green" />
            CBSE / NCERT aligned · Class 6–8
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.05 }}
            className="font-display text-[2.5rem] font-semibold leading-[1.08] tracking-tight text-navy sm:text-6xl lg:text-[3.4rem]"
          >
            Worksheets that get{" "}
            <span className="relative inline-block whitespace-nowrap">
              marked
              <SquigglyUnderline
                delay={0.6}
                className="absolute -bottom-2 left-0 h-3 w-full"
              />
            </span>
            , not just printed.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="mt-6 max-w-xl text-lg leading-relaxed text-navy/70"
          >
            Print-ready worksheet sets for Maths, Science, English and Social
            Science — built like an exam paper, marked like one too.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.25 }}
            className="mt-9 flex flex-col gap-3.5 sm:flex-row sm:items-center"
          >
            <a
              href="#catalog"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-green px-7 py-3.5 text-[15px] font-semibold text-paper shadow-card transition-all hover:bg-green-dark hover:shadow-cardHover active:scale-[0.98]"
            >
              Browse worksheets
              <ArrowRight
                size={17}
                className="transition-transform group-hover:translate-x-0.5"
              />
            </a>
            <a
              href="#how-it-works"
              className="inline-flex items-center justify-center gap-2 rounded-full border border-navy/20 bg-transparent px-7 py-3.5 text-[15px] font-semibold text-navy transition-colors hover:border-navy/40 hover:bg-navy/5"
            >
              <PlayCircle size={18} />
              How ordering works
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-navy/55"
          >
            <span>Maths</span>
            <span className="h-1 w-1 rounded-full bg-navy/25" />
            <span>Science</span>
            <span className="h-1 w-1 rounded-full bg-navy/25" />
            <span>English</span>
            <span className="h-1 w-1 rounded-full bg-navy/25" />
            <span>Social Science</span>
          </motion.div>
        </div>

        {/* Right: graded worksheet mock */}
        <motion.div
          initial={{ opacity: 0, y: 24, rotate: -1 }}
          animate={{ opacity: 1, y: 0, rotate: -1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="relative mx-auto w-full max-w-md"
        >
          <div className="relative rounded-card border border-navy/10 bg-card p-7 shadow-cardHover sm:p-9">
            <div className="mb-5 flex items-start justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-green">
                  Class 8 · English
                </p>
                <h3 className="mt-1 font-display text-xl font-semibold text-navy">
                  The Case of the Fifth Word
                </h3>
                <p className="mt-0.5 text-sm text-navy/55">
                  Unit 3: Mystery and Magic
                </p>
              </div>
              <span className="shrink-0 rounded-full bg-navy/5 px-2.5 py-1 text-xs font-semibold text-navy/60">
                /90
              </span>
            </div>

            <div className="space-y-3 border-t border-dashed border-navy/15 pt-5">
              <div className="flex items-center gap-3">
                <RedCheckmark className="h-6 w-6 shrink-0" delay={0.5} />
                <div className="h-2.5 flex-1 rounded-full bg-navy/8" />
              </div>
              <div className="flex items-center gap-3">
                <RedCheckmark className="h-6 w-6 shrink-0" delay={0.65} />
                <div className="h-2.5 w-4/5 rounded-full bg-navy/8" />
              </div>
              <div className="flex items-center gap-3">
                <span className="h-6 w-6 shrink-0" />
                <div className="h-2.5 w-3/5 rounded-full bg-navy/8" />
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between border-t border-navy/10 pt-5">
              <span className="grade-stamp rounded-md border-2 border-marker px-2.5 py-1 font-hand text-lg font-semibold text-marker">
                Full marks!
              </span>
              <CircledScore score="18/20" delay={0.8} className="h-16 w-24" />
            </div>
          </div>

          {/* subtle floating tag */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1 }}
            className="absolute -left-5 -top-5 rounded-xl border border-navy/10 bg-paper px-3.5 py-2 shadow-card sm:-left-8"
          >
            <p className="text-[11px] font-semibold uppercase tracking-wide text-marker">
              Answer key included
            </p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
