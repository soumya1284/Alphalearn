import { MessageCircle, Instagram } from "lucide-react";
import { buildInstagramLink, buildWhatsAppLink } from "@/lib/site-config";

export default function Footer() {
  return (
    <footer className="relative border-t border-navy/10 bg-navy px-5 py-14 text-paper sm:px-8">
      <div className="mx-auto max-w-8xl">
        <div className="flex flex-col gap-10 sm:flex-row sm:items-start sm:justify-between">
          <div className="max-w-md">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-paper font-display text-base font-semibold text-navy">
                A
              </span>
              <span className="font-display text-lg font-semibold tracking-tight">
                AlphaLearn <span className="italic font-normal">Studylab</span>
              </span>
            </div>
            <p className="mt-4 text-[15px] leading-relaxed text-paper/70">
              Publication-grade CBSE/NCERT worksheets for Class 6–8. Maths,
              Science, English, Social Science.
            </p>
          </div>

          <div className="flex gap-10">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-paper/50">
                Explore
              </p>
              <ul className="mt-3 space-y-2.5 text-[15px] text-paper/80">
                <li>
                  <a href="#catalog" className="transition-colors hover:text-paper">
                    Catalog
                  </a>
                </li>
                <li>
                  <a href="#how-it-works" className="transition-colors hover:text-paper">
                    How it works
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-paper/50">
                Connect
              </p>
              <ul className="mt-3 space-y-2.5 text-[15px] text-paper/80">
                <li>
                  <a
                    href={buildWhatsAppLink(
                      "Hi! I'd like to know more about AlphaLearn Studylab worksheets."
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 transition-colors hover:text-paper"
                  >
                    <MessageCircle size={15} /> WhatsApp
                  </a>
                </li>
                <li>
                  <a
                    href={buildInstagramLink()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 transition-colors hover:text-paper"
                  >
                    <Instagram size={15} /> Instagram
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-paper/10 pt-6 text-xs text-paper/45 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} AlphaLearn Studylab. All rights reserved.</p>
          <p className="max-w-lg sm:text-right">
            Note: replace the WhatsApp number and Instagram handle in{" "}
            <code className="rounded bg-paper/10 px-1.5 py-0.5">
              lib/site-config.ts
            </code>{" "}
            with real ones before publishing.
          </p>
        </div>
      </div>
    </footer>
  );
}
