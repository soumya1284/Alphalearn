"use client";

import { motion } from "framer-motion";
import { MessageCircle, FileCheck2 } from "lucide-react";
import type { Worksheet } from "@/lib/worksheets";
import { buildWhatsAppLink } from "@/lib/site-config";

const tierStyles: Record<Worksheet["tier"], string> = {
  "Concept Builder": "bg-green-light text-green-dark",
  "Concept Mastery": "bg-navy/8 text-navy",
  "Exam Mastery": "bg-marker-light text-marker-dark",
};

export default function WorksheetCard({ worksheet }: { worksheet: Worksheet }) {
  const message = `Hi! I'd like to order the worksheet: "${worksheet.title}" — Class ${worksheet.class} ${worksheet.subject} (${worksheet.unit}).`;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="group flex h-full flex-col rounded-card border border-navy/10 bg-card p-6 shadow-card transition-shadow duration-300 hover:shadow-cardHover"
    >
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wide text-green">
          Class {worksheet.class} · {worksheet.subject}
        </span>
        <span className="shrink-0 rounded-full bg-navy/5 px-2.5 py-1 text-xs font-semibold text-navy/60">
          /{worksheet.marks}
        </span>
      </div>

      <h3 className="font-display text-lg font-semibold leading-snug text-navy">
        {worksheet.title}
      </h3>
      <p className="mt-1 text-sm text-navy/55">{worksheet.unit}</p>

      <div className="mt-4 flex flex-wrap gap-2">
        <span
          className={`rounded-full px-2.5 py-1 text-xs font-semibold ${tierStyles[worksheet.tier]}`}
        >
          {worksheet.tier}
        </span>
        <span className="inline-flex items-center gap-1 rounded-full bg-navy/5 px-2.5 py-1 text-xs font-semibold text-navy/65">
          <FileCheck2 size={12} strokeWidth={2.5} />
          Full set + answer key
        </span>
      </div>

      <div className="mt-6 flex-1" />

      <a
        href={buildWhatsAppLink(message)}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-green px-4 py-2.5 text-sm font-semibold text-paper transition-colors hover:bg-green-dark active:scale-[0.98]"
      >
        <MessageCircle size={16} />
        Order on WhatsApp
      </a>
    </motion.article>
  );
}
