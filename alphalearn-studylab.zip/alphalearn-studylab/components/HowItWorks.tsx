"use client";

import { motion } from "framer-motion";
import { ListFilter, MessageCircleMore, FileDown } from "lucide-react";

const steps = [
  {
    icon: ListFilter,
    title: "Browse the catalog",
    description: "Filter by class and subject to find the chapter you need.",
  },
  {
    icon: MessageCircleMore,
    title: "Order on WhatsApp",
    description:
      "Tap Order on WhatsApp and your message is pre-filled with the worksheet name.",
  },
  {
    icon: FileDown,
    title: "Pay by UPI, get your file",
    description:
      "Pay via UPI and receive the print-ready DOCX directly on WhatsApp.",
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="relative px-5 py-20 sm:px-8 lg:py-28">
      <div className="mx-auto max-w-8xl">
        <div className="mb-14 max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-wide text-marker">
            No login required
          </p>
          <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-navy sm:text-4xl">
            Three steps, no login required.
          </h2>
        </div>

        <div className="relative grid grid-cols-1 gap-10 sm:grid-cols-3 sm:gap-6">
          {/* connecting dashed line, desktop only */}
          <div
            aria-hidden="true"
            className="absolute left-0 right-0 top-8 hidden h-px border-t-2 border-dashed border-navy/15 sm:block"
          />

          {steps.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: i * 0.12 }}
              className="relative"
            >
              <div className="relative z-10 flex h-16 w-16 items-center justify-center rounded-full border-2 border-navy bg-paper">
                <step.icon size={26} className="text-navy" strokeWidth={1.8} />
                <span className="absolute -right-1.5 -top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-marker font-hand text-sm font-bold text-paper">
                  {i + 1}
                </span>
              </div>
              <h3 className="mt-5 font-display text-xl font-semibold text-navy">
                {step.title}
              </h3>
              <p className="mt-2 max-w-xs text-[15px] leading-relaxed text-navy/65">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
