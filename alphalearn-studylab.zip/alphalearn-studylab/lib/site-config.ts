// ─────────────────────────────────────────────────────────────────────────
// ⚠️ REPLACE BEFORE PUBLISHING
// Swap in the real WhatsApp business number (with country code, no + or
// spaces) and the real Instagram handle. Every WhatsApp / Instagram link
// on the site reads from this single file.
// ─────────────────────────────────────────────────────────────────────────

export const siteConfig = {
  name: "AlphaLearn Studylab",
  tagline: "Publication-grade CBSE/NCERT worksheets for Class 6–8.",

  // TODO: replace with the real WhatsApp number, e.g. "919876543210"
  whatsappNumber: "910000000000",

  // TODO: replace with the real Instagram handle, e.g. "alphalearn.studylab"
  instagramHandle: "alphalearn.studylab",
};

export function buildWhatsAppLink(message: string) {
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${siteConfig.whatsappNumber}?text=${encoded}`;
}

export function buildInstagramLink() {
  return `https://instagram.com/${siteConfig.instagramHandle}`;
}
