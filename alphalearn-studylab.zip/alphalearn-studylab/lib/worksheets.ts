export type SchoolClass = 6 | 7 | 8;
export type Subject = "Maths" | "Science" | "English" | "Social Science";
export type Tier = "Concept Builder" | "Concept Mastery" | "Exam Mastery";

export interface Worksheet {
  id: string;
  class: SchoolClass;
  subject: Subject;
  marks: number;
  title: string;
  unit: string;
  tier: Tier;
}

export const subjects: Subject[] = [
  "Maths",
  "Science",
  "English",
  "Social Science",
];

export const classes: SchoolClass[] = [6, 7, 8];

export const worksheets: Worksheet[] = [
  // ── Class 6 ──────────────────────────────────────────────────────────
  {
    id: "c6-ma-1",
    class: 6,
    subject: "Maths",
    marks: 80,
    title: "Fractions and Their Friends",
    unit: "Unit 2: Numbers in Parts",
    tier: "Concept Builder",
  },
  {
    id: "c6-ma-2",
    class: 6,
    subject: "Maths",
    marks: 80,
    title: "Shapes All Around",
    unit: "Unit 4: Basic Geometry",
    tier: "Concept Mastery",
  },
  {
    id: "c6-sc-1",
    class: 6,
    subject: "Science",
    marks: 80,
    title: "The Living World Next Door",
    unit: "Unit 1: Living Beings",
    tier: "Concept Builder",
  },
  {
    id: "c6-sc-2",
    class: 6,
    subject: "Science",
    marks: 80,
    title: "Sorting Materials by Groups",
    unit: "Unit 3: Materials Around Us",
    tier: "Exam Mastery",
  },
  {
    id: "c6-en-1",
    class: 6,
    subject: "English",
    marks: 90,
    title: "The Kite That Flew Too Far",
    unit: "Unit 2: Tales and Journeys",
    tier: "Concept Builder",
  },
  {
    id: "c6-en-2",
    class: 6,
    subject: "English",
    marks: 90,
    title: "A Letter to the Moon",
    unit: "Unit 5: Poems and Feelings",
    tier: "Concept Mastery",
  },
  {
    id: "c6-ss-1",
    class: 6,
    subject: "Social Science",
    marks: 80,
    title: "Our Changing Earth",
    unit: "Unit 1: Geography Basics",
    tier: "Concept Builder",
  },
  {
    id: "c6-ss-2",
    class: 6,
    subject: "Social Science",
    marks: 80,
    title: "When Kings Ruled the Land",
    unit: "Unit 3: Early India",
    tier: "Exam Mastery",
  },

  // ── Class 7 ──────────────────────────────────────────────────────────
  {
    id: "c7-ma-1",
    class: 7,
    subject: "Maths",
    marks: 80,
    title: "Integers in Everyday Life",
    unit: "Unit 1: Numbers",
    tier: "Concept Builder",
  },
  {
    id: "c7-ma-2",
    class: 7,
    subject: "Maths",
    marks: 80,
    title: "Lines, Angles and Puzzles",
    unit: "Unit 5: Geometry",
    tier: "Exam Mastery",
  },
  {
    id: "c7-sc-1",
    class: 7,
    subject: "Science",
    marks: 80,
    title: "Nutrition in Plants and Animals",
    unit: "Unit 1: Life Processes",
    tier: "Concept Mastery",
  },
  {
    id: "c7-sc-2",
    class: 7,
    subject: "Science",
    marks: 80,
    title: "Heat and How It Travels",
    unit: "Unit 4: The Physical World",
    tier: "Concept Builder",
  },
  {
    id: "c7-en-1",
    class: 7,
    subject: "English",
    marks: 90,
    title: "The Storyteller's Last Trick",
    unit: "Unit 2: Stories with a Twist",
    tier: "Exam Mastery",
  },
  {
    id: "c7-en-2",
    class: 7,
    subject: "English",
    marks: 90,
    title: "Songs of the Wind",
    unit: "Unit 6: Poems",
    tier: "Concept Mastery",
  },
  {
    id: "c7-ss-1",
    class: 7,
    subject: "Social Science",
    marks: 80,
    title: "Tracing Changes Through Time",
    unit: "Unit 1: History",
    tier: "Concept Builder",
  },
  {
    id: "c7-ss-2",
    class: 7,
    subject: "Social Science",
    marks: 80,
    title: "Understanding Our Environment",
    unit: "Unit 3: Geography",
    tier: "Concept Mastery",
  },

  // ── Class 8 ──────────────────────────────────────────────────────────
  {
    id: "c8-ma-1",
    class: 8,
    subject: "Maths",
    marks: 80,
    title: "Rational Numbers Made Simple",
    unit: "Unit 1: Numbers",
    tier: "Concept Builder",
  },
  {
    id: "c8-ma-2",
    class: 8,
    subject: "Maths",
    marks: 80,
    title: "Mensuration in Motion",
    unit: "Unit 6: Measurement",
    tier: "Exam Mastery",
  },
  {
    id: "c8-sc-1",
    class: 8,
    subject: "Science",
    marks: 80,
    title: "Forces and Pressure at Work",
    unit: "Unit 3: Physics",
    tier: "Concept Mastery",
  },
  {
    id: "c8-sc-2",
    class: 8,
    subject: "Science",
    marks: 80,
    title: "Cell — The Basic Unit of Life",
    unit: "Unit 5: Biology",
    tier: "Concept Builder",
  },
  {
    id: "c8-en-1",
    class: 8,
    subject: "English",
    marks: 90,
    title: "The Magic Brush of Dreams",
    unit: "Unit 3: Mystery and Magic",
    tier: "Concept Builder",
  },
  {
    id: "c8-en-2",
    class: 8,
    subject: "English",
    marks: 90,
    title: "The Case of the Fifth Word",
    unit: "Unit 3: Mystery and Magic",
    tier: "Concept Mastery",
  },
  {
    id: "c8-en-3",
    class: 8,
    subject: "English",
    marks: 90,
    title: "Spectacular Wonders",
    unit: "Unit 3: Mystery and Magic",
    tier: "Exam Mastery",
  },
  {
    id: "c8-en-4",
    class: 8,
    subject: "English",
    marks: 90,
    title: "Letters from a Distant Land",
    unit: "Unit 5: Real-Life Stories",
    tier: "Concept Builder",
  },
  {
    id: "c8-ss-1",
    class: 8,
    subject: "Social Science",
    marks: 80,
    title: "The Making of a Nation",
    unit: "Unit 2: Modern India",
    tier: "Concept Mastery",
  },
  {
    id: "c8-ss-2",
    class: 8,
    subject: "Social Science",
    marks: 80,
    title: "Resources and Development",
    unit: "Unit 4: Geography",
    tier: "Exam Mastery",
  },
];
