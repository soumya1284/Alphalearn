import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Catalog from "@/components/Catalog";
import HowItWorks from "@/components/HowItWorks";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="relative">
      <Navbar />
      <Hero />
      <div className="relative">
        {/* faint red margin rule running behind catalog + how-it-works, notebook-style */}
        <div className="notebook-margin absolute inset-0 hidden lg:block" />
        <Catalog />
        <HowItWorks />
      </div>
      <Footer />
    </main>
  );
}
