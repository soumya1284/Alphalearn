import type { Metadata } from "next";
import { Fraunces, Inter, Caveat } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const caveat = Caveat({
  subsets: ["latin"],
  variable: "--font-caveat",
  weight: ["500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "AlphaLearn Studylab — CBSE/NCERT Worksheets, Class 6–8",
  description:
    "Publication-grade CBSE/NCERT worksheet sets for Class 6–8. Maths, Science, English and Social Science — print-ready, ordered on WhatsApp.",
  keywords: [
    "CBSE worksheets",
    "NCERT worksheets",
    "Class 6 worksheets",
    "Class 7 worksheets",
    "Class 8 worksheets",
    "print ready worksheets",
  ],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body
        className={`${fraunces.variable} ${inter.variable} ${caveat.variable} font-body notebook-bg antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
